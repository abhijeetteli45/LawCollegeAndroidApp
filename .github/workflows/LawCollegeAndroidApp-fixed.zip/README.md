# Law College Manager — Android starter app

This is a native Android Studio project for an initial offline student and fee-management app.

## Included
- 3-year LL.B. and 5-year B.A. LL.B. academic years
- CAP Round / Management admission category
- Regular / Paid Attendance student type
- Student and parent/guardian mobile numbers
- College fee, donation, attendance fee, paid amounts, balances and due date
- Search student records and record payments
- Local SQLite database on the Android phone

## Build and install
1. On a computer, install Android Studio (current stable version).
2. Open the `LawCollegeAndroid` project folder in Android Studio.
3. Allow Gradle sync to finish; install the Android SDK requested by the project if prompted.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press **Run** to install the app.
6. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Important limitations of this first version
- Data is stored only on this phone; uninstalling the app or losing the phone can erase records.
- No cloud sync, login/permissions, export to Excel/PDF, or formal printable receipts yet.
- Payment entries increase the paid total, but this starter version does not yet maintain a separate transaction ledger or enforce a maximum payment against the outstanding balance.
- The date field is stored as entered and is not validated.
- Please test with sample data before entering official student records, and maintain secure backups.
