package com.csmlck.management

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

data class Student(
    val id: Long, val name: String, val admissionNo: String, val course: String,
    val year: String, val admissionCategory: String, val studentType: String,
    val studentMobile: String, val parentName: String, val parentMobile: String,
    val collegeFee: Double, val donation: Double, val attendanceFee: Double,
    val collegePaid: Double, val donationPaid: Double, val attendancePaid: Double,
    val dueDate: String
)

class DBHelper(context: Activity) : SQLiteOpenHelper(context, "law_college.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE students(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, admission_no TEXT,
            course TEXT, year TEXT, admission_category TEXT, student_type TEXT,
            student_mobile TEXT, parent_name TEXT, parent_mobile TEXT,
            college_fee REAL DEFAULT 0, donation REAL DEFAULT 0, attendance_fee REAL DEFAULT 0,
            college_paid REAL DEFAULT 0, donation_paid REAL DEFAULT 0, attendance_paid REAL DEFAULT 0,
            due_date TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(values: ContentValues) = writableDatabase.insert("students", null, values)
    fun all(): List<Student> {
        val list = mutableListOf<Student>()
        val c = readableDatabase.rawQuery("SELECT * FROM students ORDER BY name COLLATE NOCASE", null)
        c.use {
            while (it.moveToNext()) {
                fun s(col: String) = it.getString(it.getColumnIndexOrThrow(col)) ?: ""
                fun d(col: String) = it.getDouble(it.getColumnIndexOrThrow(col))
                list.add(Student(it.getLong(0), s("name"), s("admission_no"), s("course"), s("year"),
                    s("admission_category"), s("student_type"), s("student_mobile"), s("parent_name"),
                    s("parent_mobile"), d("college_fee"), d("donation"), d("attendance_fee"),
                    d("college_paid"), d("donation_paid"), d("attendance_paid"), s("due_date")))
            }
        }
        return list
    }
    fun remove(id: Long) { writableDatabase.delete("students", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: DBHelper
    private lateinit var root: LinearLayout
    private var searchText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DBHelper(this)
        render()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 14f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = value; textSize = size; setTextColor(Color.rgb(32, 45, 60))
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(5), dp(2), dp(5))
        }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { action() }
    }
    private fun field(hintText: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            hint = hintText; inputType = type; textSize = 15f
            setSingleLine(true); setPadding(dp(10), dp(4), dp(10), dp(4))
        }
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }
    private fun addLine(label: String, view: View) {
        root.addView(text(label, 13f, true))
        root.addView(view)
    }
    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(16))
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("LAW COLLEGE MANAGER", 22f, true))
        content.addView(text("Chhatrapati Shivaji Maharaj Law College, Korochi", 13f))
        val stats = db.all()
        content.addView(text("Students: ${stats.size}   |   Pending fees: ₹${"%.2f".format(stats.sumOf { (it.collegeFee-it.collegePaid).coerceAtLeast(0.0) + (it.donation-it.donationPaid).coerceAtLeast(0.0) + (it.attendanceFee-it.attendancePaid).coerceAtLeast(0.0) })}", 15f, true))
        content.addView(button("+ Add Student") { addStudent() })
        val search = field("Search name / admission no / mobile")
        search.setText(searchText)
        search.setOnEditorActionListener { _, _, _ -> searchText = search.text.toString(); render(); true }
        content.addView(search)
        content.addView(text("STUDENT RECORDS", 17f, true))
        val filtered = stats.filter {
            val q = searchText.lowercase()
            q.isBlank() || listOf(it.name, it.admissionNo, it.studentMobile, it.parentMobile).any { x -> x.lowercase().contains(q) }
        }
        if (filtered.isEmpty()) content.addView(text("No students yet. Tap “Add Student” to create the first record."))
        filtered.forEach { st ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(Color.WHITE)
            }
            card.addView(text(st.name, 17f, true))
            card.addView(text("${st.admissionNo} • ${st.course} • ${st.year}"))
            card.addView(text("${st.admissionCategory} / ${st.studentType}"))
            card.addView(text("Student mobile: ${st.studentMobile.ifBlank { "—" }}"))
            card.addView(text("Parent: ${st.parentName.ifBlank { "—" }} • ${st.parentMobile.ifBlank { "—" }}"))
            card.addView(text("College fee: ₹${st.collegeFee} | Paid ₹${st.collegePaid} | Balance ₹${(st.collegeFee-st.collegePaid).coerceAtLeast(0.0)}"))
            if (st.donation > 0) card.addView(text("Donation: ₹${st.donation} | Paid ₹${st.donationPaid} | Balance ₹${(st.donation-st.donationPaid).coerceAtLeast(0.0)}"))
            if (st.attendanceFee > 0) card.addView(text("Attendance fee: ₹${st.attendanceFee} | Paid ₹${st.attendancePaid} | Balance ₹${(st.attendanceFee-st.attendancePaid).coerceAtLeast(0.0)}"))
            card.addView(text("Payment due date: ${st.dueDate.ifBlank { "Not set" }}"))
            card.addView(button("Record Payment") { recordPayment(st) })
            card.addView(button("Delete Record") {
                AlertDialog.Builder(this).setTitle("Delete student?")
                    .setMessage("This will permanently delete ${st.name} from this phone.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> db.remove(st.id); render() }.show()
            })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10)
            content.addView(card, lp)
        }
        content.addView(text("Data is stored locally on this Android phone. Back up your records regularly.", 12f))
        root.addView(content)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addStudent() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val sc = ScrollView(this)
        val name = field("Student full name")
        val adm = field("Admission number")
        val course = spinner(listOf("LL.B. (3 Year)", "B.A. LL.B. (5 Year)"))
        val year3 = listOf("First Year", "Second Year", "Third Year")
        val year5 = listOf("First Year", "Second Year", "Third Year", "Fourth Year", "Fifth Year")
        val year = spinner(year3)
        course.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                year.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, if (position == 0) year3 else year5)
            }
        }
        val admissionCategory = spinner(listOf("CAP Round", "Management"))
        val studentType = spinner(listOf("Regular", "Paid Attendance"))
        val studentMobile = field("Student mobile number", InputType.TYPE_CLASS_PHONE)
        val parentName = field("Parent / guardian name")
        val parentMobile = field("Parent / guardian mobile", InputType.TYPE_CLASS_PHONE)
        val collegeFee = field("College fee decided (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val donation = field("Donation decided (₹, if applicable)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val attendanceFee = field("Attendance fee decided (₹, if applicable)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val collegePaid = field("College fee already paid (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val donationPaid = field("Donation already paid (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val attendancePaid = field("Attendance fee already paid (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val dueDate = field("Fee due date (e.g. 30-09-2026)")
        listOf(
            "Student name" to name, "Admission number" to adm, "Course" to course, "Academic year" to year,
            "Admission category" to admissionCategory, "Student type" to studentType,
            "Student mobile" to studentMobile, "Parent / guardian name" to parentName,
            "Parent / guardian mobile" to parentMobile, "College fee" to collegeFee,
            "Donation" to donation, "Attendance fee" to attendanceFee, "College fee paid" to collegePaid,
            "Donation paid" to donationPaid, "Attendance fee paid" to attendancePaid, "Fee due date" to dueDate
        ).forEach { (label, view) -> form.addView(text(label, 13f, true)); form.addView(view) }
        sc.addView(form)
        AlertDialog.Builder(this).setTitle("Add Student").setView(sc)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                if (name.text.toString().trim().isEmpty()) {
                    Toast.makeText(this, "Student name is required.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val cat = admissionCategory.selectedItem.toString()
                val type = studentType.selectedItem.toString()
                val cv = ContentValues().apply {
                    put("name", name.text.toString().trim()); put("admission_no", adm.text.toString().trim())
                    put("course", course.selectedItem.toString()); put("year", year.selectedItem.toString())
                    put("admission_category", cat); put("student_type", type)
                    put("student_mobile", studentMobile.text.toString().trim())
                    put("parent_name", parentName.text.toString().trim()); put("parent_mobile", parentMobile.text.toString().trim())
                    put("college_fee", num(collegeFee.text.toString()))
                    put("donation", if (cat == "Management") num(donation.text.toString()) else 0.0)
                    put("attendance_fee", if (type == "Paid Attendance") num(attendanceFee.text.toString()) else 0.0)
                    put("college_paid", num(collegePaid.text.toString()))
                    put("donation_paid", if (cat == "Management") num(donationPaid.text.toString()) else 0.0)
                    put("attendance_paid", if (type == "Paid Attendance") num(attendancePaid.text.toString()) else 0.0)
                    put("due_date", dueDate.text.toString().trim())
                }
                db.add(cv); render()
            }.show()
    }

    private fun num(s: String): Double = s.trim().toDoubleOrNull() ?: 0.0

    private fun recordPayment(st: Student) {
        val options = mutableListOf<String>()
        if (st.collegeFee > 0) options.add("College Fee")
        if (st.donation > 0) options.add("Donation")
        if (st.attendanceFee > 0) options.add("Attendance Fee")
        if (options.isEmpty()) {
            Toast.makeText(this, "Add fee amounts to this student first.", Toast.LENGTH_LONG).show()
            return
        }
        val type = spinner(options)
        val amount = field("Payment amount (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val date = field("Payment date (e.g. 12-10-2026)")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        box.addView(text("Fee component")); box.addView(type)
        box.addView(text("Amount received")); box.addView(amount)
        box.addView(text("Payment date")); box.addView(date)
        AlertDialog.Builder(this).setTitle("Record Payment — ${st.name}").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Save Payment") { _, _ ->
                val a = num(amount.text.toString())
                if (a <= 0) { Toast.makeText(this, "Enter a valid amount.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val col = when (type.selectedItem.toString()) {
                    "College Fee" -> "college_paid"
                    "Donation" -> "donation_paid"
                    else -> "attendance_paid"
                }
                val current = when (col) {
                    "college_paid" -> st.collegePaid
                    "donation_paid" -> st.donationPaid
                    else -> st.attendancePaid
                }
                val cv = ContentValues().apply { put(col, current + a) }
                db.writableDatabase.update("students", cv, "id=?", arrayOf(st.id.toString()))
                Toast.makeText(this, "Payment saved. Date: ${date.text}", Toast.LENGTH_LONG).show()
                render()
            }.show()
    }
}
